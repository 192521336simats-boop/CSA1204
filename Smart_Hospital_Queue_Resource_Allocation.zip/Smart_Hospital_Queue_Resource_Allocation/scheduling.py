import pandas as pd

def fcfs_schedule(df):
    x = df.sort_values(["Arrival","Patient ID"]).copy()
    current = 0
    starts, finishes = [], []
    for _, row in x.iterrows():
        start = max(current, int(row["Arrival"]))
        finish = start + int(row["Burst"])
        starts.append(start); finishes.append(finish); current = finish
    x["Start"] = starts
    x["Completion"] = finishes
    x["Waiting"] = x["Start"] - x["Arrival"]
    x["Turnaround"] = x["Completion"] - x["Arrival"]
    x["Response"] = x["Start"] - x["Arrival"]
    return x

def priority_schedule(df):
    remaining = df.copy()
    ordered = []
    current = 0
    while len(remaining):
        available = remaining[remaining["Arrival"] <= current]
        if len(available) == 0:
            current = int(remaining["Arrival"].min())
            available = remaining[remaining["Arrival"] <= current]
        pick = available.sort_values(["Priority","Arrival","Patient ID"]).iloc[0]
        ordered.append(pick)
        remaining = remaining.drop(pick.name)
        current += int(pick["Burst"])
    x = pd.DataFrame(ordered)
    current = 0
    starts, finishes = [], []
    for _, row in x.iterrows():
        start = max(current, int(row["Arrival"]))
        finish = start + int(row["Burst"])
        starts.append(start); finishes.append(finish); current = finish
    x["Start"] = starts
    x["Completion"] = finishes
    x["Waiting"] = x["Start"] - x["Arrival"]
    x["Turnaround"] = x["Completion"] - x["Arrival"]
    x["Response"] = x["Start"] - x["Arrival"]
    return x

def calculate_metrics(result):
    total_burst = result["Burst"].sum()
    span = max(result["Completion"].max(), 1) - min(result["Arrival"].min(), 0)
    return {
        "avg_waiting": result["Waiting"].mean(),
        "avg_turnaround": result["Turnaround"].mean(),
        "avg_response": result["Response"].mean(),
        "throughput": len(result)/span if span else 0
    }

def allocate_resources(df, doctors, rooms):
    x = df.sort_values(["Priority","Arrival"]).copy()
    x["Doctor"] = [(i % doctors)+1 for i in range(len(x))]
    x["Treatment Room"] = [(i % rooms)+1 for i in range(len(x))]
    x["Processing Unit"] = x["Doctor"].apply(lambda n: f"CPU-{n}")
    return x[["Patient ID","Name","Department","Priority","Emergency","Doctor","Treatment Room","Processing Unit"]]

def simulate_io(patient):
    return [
        f"Registration I/O → {patient}",
        f"Doctor Allocation I/O → {patient}",
        f"Laboratory I/O → {patient}",
        f"Pharmacy I/O → {patient}",
        f"Billing I/O → {patient}",
        f"Discharge I/O → {patient}"
    ]
