import streamlit as st
import pandas as pd
from scheduling import fcfs_schedule, priority_schedule, calculate_metrics, allocate_resources, simulate_io

st.set_page_config(page_title="Smart Hospital", page_icon="🏥", layout="wide")

if "patients" not in st.session_state:
    st.session_state.patients = pd.DataFrame([
        {"Patient ID":"P001","Name":"Arun","Department":"General","Arrival":0,"Burst":8,"Priority":3,"Emergency":"No"},
        {"Patient ID":"P002","Name":"Priya","Department":"Cardiology","Arrival":1,"Burst":5,"Priority":2,"Emergency":"No"},
        {"Patient ID":"P003","Name":"Rahul","Department":"Emergency","Arrival":2,"Burst":4,"Priority":1,"Emergency":"Yes"},
        {"Patient ID":"P004","Name":"Meena","Department":"General","Arrival":3,"Burst":6,"Priority":4,"Emergency":"No"},
        {"Patient ID":"P005","Name":"Kavin","Department":"Orthopedics","Arrival":4,"Burst":3,"Priority":3,"Emergency":"No"},
        {"Patient ID":"P006","Name":"Divya","Department":"Emergency","Arrival":5,"Burst":2,"Priority":1,"Emergency":"Yes"},
    ])

st.title("🏥 Smart Hospital Queue & Resource Allocation System")
st.caption("Computer Architecture simulation: CPU scheduling, parallel processing, interrupts and I/O optimization")

with st.sidebar:
    st.header("Navigation")
    page = st.radio("Open module", [
        "Dashboard", "Patient Registration", "CPU Scheduling",
        "Resource Allocation", "Emergency Interrupt", "I/O Simulation",
        "Performance Analysis"
    ])

df = st.session_state.patients.copy()

if page == "Dashboard":
    st.subheader("System Dashboard")
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("Total Patients", len(df))
    c2.metric("Emergency Patients", int((df["Emergency"]=="Yes").sum()))
    c3.metric("Doctors", 3)
    c4.metric("Treatment Rooms", 3)

    st.divider()
    st.subheader("Current Patient Queue")
    st.dataframe(df, use_container_width=True, hide_index=True)

    st.subheader("Architecture Mapping")
    st.info("Patients = computational tasks | Doctors = processing units | Burst time = treatment/execution time | Priority 1 = highest urgency | Emergency = interrupt request")

elif page == "Patient Registration":
    st.subheader("👤 Patient Registration")
    with st.form("patient_form"):
        a,b = st.columns(2)
        pid = a.text_input("Patient ID", f"P{len(df)+1:03d}")
        name = b.text_input("Patient Name")
        dept = a.selectbox("Department", ["General","Emergency","Cardiology","Orthopedics","Neurology"])
        arrival = b.number_input("Arrival Time", min_value=0, value=len(df))
        burst = a.number_input("Treatment / Burst Time", min_value=1, value=5)
        emergency = b.checkbox("Emergency patient")
        priority = 1 if emergency else a.number_input("Priority (1 = highest)", min_value=2, max_value=5, value=3)
        submitted = st.form_submit_button("Register Patient")
    if submitted:
        new = pd.DataFrame([{"Patient ID":pid,"Name":name or "Patient","Department":dept,
                             "Arrival":arrival,"Burst":burst,"Priority":priority,
                             "Emergency":"Yes" if emergency else "No"}])
        st.session_state.patients = pd.concat([df,new], ignore_index=True)
        st.success(f"{pid} registered successfully.")
        st.rerun()

elif page == "CPU Scheduling":
    st.subheader("⚙️ CPU Scheduling Simulation")
    algo = st.selectbox("Select scheduling algorithm", ["FCFS","Priority Scheduling"])
    result = fcfs_schedule(df) if algo=="FCFS" else priority_schedule(df)
    metrics = calculate_metrics(result)
    st.dataframe(result, use_container_width=True, hide_index=True)

    st.subheader("Gantt-style Execution Order")
    st.write(" → ".join(result["Patient ID"].tolist()))
    c1,c2,c3 = st.columns(3)
    c1.metric("Average Waiting Time", f"{metrics['avg_waiting']:.2f}")
    c2.metric("Average Turnaround Time", f"{metrics['avg_turnaround']:.2f}")
    c3.metric("Average Response Time", f"{metrics['avg_response']:.2f}")

elif page == "Resource Allocation":
    st.subheader("🏥 Parallel Resource Allocation")
    doctors = st.slider("Number of doctors / processing units", 1, 6, 3)
    rooms = st.slider("Treatment rooms", 1, 6, 3)
    alloc = allocate_resources(df, doctors, rooms)
    st.dataframe(alloc, use_container_width=True, hide_index=True)
    st.success("Multiple doctors are simulated as independent processing units.")

elif page == "Emergency Interrupt":
    st.subheader("🚨 Emergency Interrupt Handling")
    normal = df[df["Emergency"]=="No"]
    emergency = df[df["Emergency"]=="Yes"]
    st.write("Normal processing queue:")
    st.write(" → ".join(normal["Patient ID"].tolist()) if len(normal) else "Empty")
    st.write("Emergency interrupt:")
    if len(emergency):
        st.error("🚨 Emergency request detected — normal queue is interrupted.")
        st.write(" → ".join(emergency["Patient ID"].tolist()))
        st.write("Emergency patients receive Priority = 1 and are served first.")
    else:
        st.info("No emergency patient currently registered.")

elif page == "I/O Simulation":
    st.subheader("🔄 Hospital I/O Communication Simulation")
    patient = st.selectbox("Select patient", df["Patient ID"].tolist())
    stages = simulate_io(patient)
    for i, stage in enumerate(stages, 1):
        st.success(f"{i}. {stage}")
    st.info("This simulates communication between registration, doctor allocation, laboratory, pharmacy, billing and discharge.")

elif page == "Performance Analysis":
    st.subheader("📊 Performance Comparison")
    fc = calculate_metrics(fcfs_schedule(df))
    pr = calculate_metrics(priority_schedule(df))
    comparison = pd.DataFrame({
        "Metric":["Average Waiting Time","Average Turnaround Time","Average Response Time","Throughput"],
        "FCFS":[fc["avg_waiting"],fc["avg_turnaround"],fc["avg_response"],fc["throughput"]],
        "Priority Scheduling":[pr["avg_waiting"],pr["avg_turnaround"],pr["avg_response"],pr["throughput"]]
    })
    st.dataframe(comparison, use_container_width=True, hide_index=True)
    st.bar_chart(comparison.set_index("Metric"))
    st.subheader("Engineering Recommendation")
    if pr["avg_waiting"] < fc["avg_waiting"]:
        st.success("For this workload, Priority Scheduling gives lower average waiting time and is recommended for urgent hospital cases.")
    else:
        st.info("For this workload, FCFS has the lower average waiting time. Test additional workloads before selecting the final policy.")
    st.caption("Run the system with normal traffic, high patient volume, limited doctors and multiple emergency cases for your report.")

st.sidebar.divider()
st.sidebar.caption("Educational simulation — not a real medical decision system.")
