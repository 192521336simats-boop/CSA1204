# Smart Hospital Queue and Resource Allocation System

## Purpose
A simple educational simulation for the Computer Architecture assessment.

## Concepts demonstrated
- FCFS CPU scheduling
- Priority scheduling
- Waiting, turnaround and response time
- Throughput
- Parallel processing/resource allocation
- Emergency interrupt handling
- Hospital I/O communication
- Performance comparison dashboard

## Run
1. Open this folder in VS Code.
2. Open Terminal.
3. Run: `python -m pip install -r requirements.txt`
4. Run: `python -m streamlit run app.py`
5. Open the browser URL shown in the terminal.

## Assessment mapping
Patients are computational tasks. Doctors/treatment rooms are processing resources. Emergency cases are interrupt requests. Hospital modules are simulated as I/O communication stages.

## Important
This is an educational simulation, not a real medical system.
